declare module 'html2pdf.js' {
  interface Html2PdfOptions {
    margin?: number | number[]
    filename?: string
    image?: { type?: string; quality?: number }
    html2canvas?: Record<string, unknown>
    jsPDF?: Record<string, unknown>
    pagebreak?: Record<string, unknown>
  }
  interface Html2Pdf {
    set(options: Html2PdfOptions): Html2Pdf
    from(element: HTMLElement): Html2Pdf
    save(): Promise<void>
  }
  function html2pdf(): Html2Pdf
  export default html2pdf
}

declare module '@paystack/inline-js' {
  interface TransactionOptions {
    key: string
    email: string
    amount: number
    currency?: string
    reference?: string
    metadata?: Record<string, unknown>
    onSuccess?: (transaction: { reference: string; status: string }) => void
    onCancel?: () => void
    onError?: (error: { message: string }) => void
  }
  export default class PaystackPop {
    newTransaction(options: TransactionOptions): void
  }
}
