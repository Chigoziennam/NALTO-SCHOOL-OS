# NALTO SchoolOS — Work Specification & Billing Structure

> Feed this document to the proposal writer. It defines WHAT the system does,
> HOW the tiers differ, and HOW billing works. The proposal AI handles tone,
> narrative and school-facing language. Positioning line: **NALTO OS — the
> symbol of conquering school administration.**

---

## 1. What the system is

NALTO SchoolOS is a school fee operations platform. It gives parents a
self-service portal to see exactly what they owe and pay online (in full, in
part, or per fee item), and gives the school a live bursary console that
replaces manual ledgers, receipt books and end-of-term reconciliation.

Built on: React + TypeScript web app, Supabase (Postgres) data layer,
Paystack payments, n8n automation workflows (receipts, reminders,
notifications). Fully responsive — the bursar can run the whole desk from a
phone.

## 2. Core capabilities (all tiers)

| Area | Capability |
|---|---|
| Parent portal | Per-child fee dashboard: billed, paid, balance, status at a glance |
| Invoicing | Itemised term invoices (tuition, PTA, exam, uniform, etc.), PDF download with school crest |
| Payments | Paystack card/bank/USSD checkout; **full payment, part payment (min ₦1,000), or pick-the-items-you-want checkout** |
| Part payment | Any amount towards the balance; remainder stays on the invoice; every payment recorded and receipted |
| Receipts | Auto-generated receipt per payment, printable/confirmable at the school office |
| Uniform shop | Size selection + online payment, collect at school |
| Bursar console | Live collections dashboard, class-by-class summaries, record offline payments (cash/POS/transfer/cheque), owing-students list, printable term report |
| Design | School's own crest, colours and photography — feels like the school's property, not a vendor's |

## 3. Tier structure

### Tier 1 — "Foundation" · ₦300,000 setup + ₦10,000/month
Everything in Core capabilities above. Parents pay online, print/confirm
receipts at the office. Bursar console included. Email receipts only.

### Tier 2 — "Notify" · ₦350,000 setup + ₦12,500/month
Tier 1 **plus automated payment verification to phones**:
- SMS confirmation to the guardian's number on every successful payment
- WhatsApp receipt with amount, reference and remaining balance
- Automated fee reminders (3 escalating nudges before due date) via SMS/WhatsApp
- Delivery costs for SMS/WhatsApp passed through at cost or bundled (see 5.3)

### Tier 3 — "Command" · ₦400,000 setup + ₦15,000/month
Tier 2 **plus the Principal's Overview**:
- Executive dashboard: total collected, outstanding, collection-rate %, term-over-term trend
- Class and section drill-downs; top-owing list with guardian contacts
- Daily/weekly digest to the principal (email + WhatsApp)
- Exportable board-meeting report (PDF)

**Upgrade path:** a school on Tier 1 upgrades by paying the difference in
setup fee (e.g. ₦50,000 to move to Tier 2) — no rebuild, features unlock.

## 4. How the system works (flow summary)

1. Bursar loads students, classes and the term's fee schedule (or NALTO does it at onboarding — included in setup).
2. System issues itemised invoices per student.
3. Parent logs in, sees balance, chooses: full payment / part payment / specific fee items → Paystack checkout.
4. Webhook confirms payment → ledger updated instantly → receipt issued (email; SMS/WhatsApp on Tier 2+).
5. Bursar console reflects every naira in real time; offline payments (cash/POS) are recorded by the bursar and reconciled in the same ledger.
6. Principal (Tier 3) watches collections without asking the bursar for spreadsheets.

## 5. Billing mechanics

### 5.1 Setup fee (one-time)
Covers: branding & white-labelling, data onboarding (students, classes, fee
schedules), Paystack merchant setup, staff training session, go-live support
for the first fee cycle. 50% due on signing, 50% on go-live.

### 5.2 Monthly fee
Covers hosting, security updates, backups, support (WhatsApp/phone), and
minor changes (fee schedule updates each term). Billed per school, due 1st
of the month; termly prepay (4 months for price of 3.7) offered as incentive.

### 5.3 Pass-through costs (not NALTO margin)
- Paystack transaction fees: paid by parent at checkout (standard NG rates ~1.5% + ₦100, capped ₦2,000) or absorbed by school — school's choice.
- SMS delivery (~₦4–6/msg) and WhatsApp Business API costs: billed at cost monthly on Tier 2/3, or capped bundle (e.g. 1,000 messages/month included, overage at cost).

### 5.4 Contract terms to state in the proposal
- 12-month initial term on the monthly fee; setup fee non-refundable after go-live.
- Data belongs to the school; full export provided on request or exit.
- 99% uptime target; support response within 4 business hours.

## 6. Assessment of the pricing (candid)

- ₦300k/₦350k/₦400k setup with ₦10–15k monthly is **credible for a private
  Catholic school in Nigeria** and undercuts typical school-portal vendors
  (₦500k–₦1.5m setups) while the monthly is low enough to never be the reason
  a school cancels.
- The ₦50k gap between tiers is small — good, it pushes schools toward Tier 2/3
  where the recurring revenue is higher. Consider presenting Tier 2 as
  "most popular" in the proposal.
- The real risk is underpricing the monthly: SMS/WhatsApp costs on Tier 2 can
  eat ₦12,500/month at scale (700 students × 3 reminders × ₦5 ≈ ₦10,500).
  **Keep messaging as a pass-through or capped bundle** (5.3) or Tier 2's
  margin goes negative in exam season.
- Anchor value on recovered revenue: if the portal lifts collection rate by
  even 5% on ~₦20m termly billing, that's ₦1m/term recovered — the system
  pays for itself in the first term. Lead the proposal with that.

## 7. Out of scope (state clearly to avoid scope creep)

Academic records/results, timetables, e-learning, staff payroll, admissions.
Each is a future paid module — mention as roadmap, not commitment.
